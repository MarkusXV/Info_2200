﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2_WeatherApp
{
  internal class WeatherGV
  {
    public static string City { get; set; }
    public static double CurTemp { get; set; }
    public static double Low { get; set; }
    public static double High { get; set; }
    public static int Pressure { get; set; }
    public static int Humidity { get; set; }
    public static double WindSpeed { get; set; }
    public static double WindDegrees { get; set; }
    public static DateTime Sunrise { get; set; }
    public static DateTime Sunset { get; set; }


  }
}
