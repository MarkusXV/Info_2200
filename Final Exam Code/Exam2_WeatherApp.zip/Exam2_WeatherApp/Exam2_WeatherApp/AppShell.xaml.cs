﻿namespace Exam2_WeatherApp;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
