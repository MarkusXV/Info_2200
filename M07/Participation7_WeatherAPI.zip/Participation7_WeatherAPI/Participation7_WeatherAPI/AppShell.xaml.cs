﻿namespace Participation7_WeatherAPI;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}
