﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Participation7_WeatherAPI
{
  internal class WeatherGV
  {
    public static string City { get; set; } //Creates the variable City so we can set it and read it
    public static double CurTemp { get; set; } //Creates the variable CurTemp so we can set it and read it
    public static double Low { get; set; } //Creates the variable Low so we can set it and read it 
    public static double High { get; set; } //Creates the variable High so we can set it and read it

  }
}
